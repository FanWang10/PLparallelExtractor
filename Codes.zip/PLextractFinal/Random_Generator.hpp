#ifndef RANDOM_GENERATOR_HPP
#define RANDOM_GENERATOR_HPP
#include <random>
#include <algorithm>


// Generates random double number from -1 to max
double random_number_double(double max);

// Genrates random int number from 1.0 to 10
int random_number_int();

#endif

