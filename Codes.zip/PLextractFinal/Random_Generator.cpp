#include "Random_Generator.hpp"

// Generates random double number from 0 to max
double random_number_double(double max)
{
    std::random_device dev;     // the seed generator
    std::mt19937 gen(dev());    // mersenne_twister_engine seeded with rd()
    std::uniform_real_distribution<> dis(-1.0, max);
    return dis(gen);
}

// Generates random int number from 1 to 10
int random_number_int()
{
    std::random_device dev;
    std::mt19937 gen(dev());
    std::uniform_int_distribution<int> dis(1.0, 10.0);
    return dis(gen);
}