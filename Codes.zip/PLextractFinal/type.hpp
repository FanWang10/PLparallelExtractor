#ifndef TYPE_HPP
#define TYPE_HPP

struct vec3
{
    double x, y, z;
};

struct vec4
{
    double a, b, c, d;
};

struct vertex
{
    vec3 v;
    vec3 w;
    int index;
};

struct tetrahedron
{

};

#endif