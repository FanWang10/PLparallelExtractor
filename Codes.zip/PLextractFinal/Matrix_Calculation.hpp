#ifndef MATRIX_CALCULATION_HPP
#define MATRIX_CALCULATION_HPP
#include "type.hpp"

double get_determinant_3(double ** mat);

void get_inverse_3(double ** mat, double ** mat_inv);

void mat_3_multiply(double ** a, double ** b, double ** result);

void mat_multiply_vec_3x3(double ** mat, double * vec);

#endif