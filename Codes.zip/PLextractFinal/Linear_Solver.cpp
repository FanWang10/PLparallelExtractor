#include "Linear_Solver.hpp"

void compute_lu_decomp(double ** A, double ** L, double ** U, int n)
{
    int i, j, k;
    double sum = 0;

    for(i = 0; i < n; i++)
    {
        U[i][i] = 1;
    }

    for(j = 0; j < n; j++)
    {
        for(i = j; i < n; i++)
        {
            sum = 0;
            for(k = 0; k < j; k++)
            {
                sum = sum + L[i][k] * U[k][j];
            }
            L[i][j] = A[i][j] - sum;
        }

        for(i = j; i < n; i++)
        {
            sum = 0;
            for(k = 0; k < j; k++)
            {
                sum = sum + L[j][k] * U[k][i];
            }
            if(L[i][j] == 0)
            {
                std::cout << "det(L) close to 0\n";
                return;
            }
            U[j][i] = (A[j][i] - sum) / L[j][j];
        }
    
    }   
}

void solve_lu(double ** L, double ** U, double * b, double * x, int n)
{
    // Solve For Y | L x Y = B; Y = U x X
    double * y = new double[n];
    for(int i = 0; i < n; i++)
    {
        y[i] = b[i];
        for(int j = 0; j <= i - 1; j++)
        {
            y[i] -= L[i][j] * y[j];
        }
        y[i] /= L[i][i];
    }
    
    // Solve For X | U x X = Y
    for(int i = n - 1; i >= 0; i--)
    {
        x[i] = y[i];
        for(int j = i + 1; j < n; j++)
        {
            x[i] -= U[i][j] * x[j];
        }

    }
}

void solve_linear_system(double ** A, double * b, int n, double* x)
{
    double ** L = new double * [n];
    for(int i = 0; i < n; i++)
    {
        L[i] = new double[n];
    }

    double ** U = new double * [n];
    for(int i = 0; i < n; i++)
    {
        U[i] = new double[n];
    }

    compute_lu_decomp(A, L, U, n);
    solve_lu(L, U, b, x, n);
}
