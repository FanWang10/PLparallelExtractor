#ifndef INVERSE_POWER_ITERATION_HPP
#define INVERSE_POWER_ITERATION_HPP
#include "Random_Generator.hpp"
#include "Matrix_Calculation.hpp"

double compute_delta_inverse_power_iteration_3x3(double * vec, double * preVec);

void normalize_vec3(double * vec);

void inverse_power_iteration_3x3(double ** A, double eigenvalue, double * eigenvector);

#endif