#include <iostream>
#include <vector>
#include <utility>   
#include "type.hpp"
#include "PL_Extract.hpp"
#include "Draw_Line.hpp"

// Print the vector
void print_vector(const vec3 & v)
{
    std::cout << "Vector (" << v.x << ", " << v.y << ", " << v.z << ") \n";
}



int main()
{
    int cellVertexNum = 4;
    int cellFaceNum = cellVertexNum;
    /*
        Implement Extraction For A Single Tetrahedron
    */
        /*
            1. Create ONE tetrahedron, a tetrahedron has 4 vertexs 
        */
        vertex tetrahedron[4];
            /*
                Initiate 4 vertexs, each has two vector values
            */
            // INITIATE SPECIAL CASES
            // vec3 v0{0, 0, 0};
            // vec3 w0{0, 0, 0};
            // vec3 v1{1, 1, 1};
            // vec3 w1{1, 1, 1};
            // vec3 v2{2, 2, 2};
            // vec3 w2{2, 2, 2};
            // vec3 v3{3, 3, 3};
            // vec3 w3{3, 3, 3};
            // vertex ver0{v0, w0, 0};
            // vertex ver1{v1, w1, 1};
            // vertex ver2{v2, w2, 2};
            // vertex ver3{v3, w3, 3};
            // tetrahedron[0] = ver0;
            // tetrahedron[1] = ver1;
            // tetrahedron[2] = ver2;
            // tetrahedron[3] = ver3;

            // INITIATE RANDOMLY
            for(int i = 0; i < cellVertexNum; i++)
            {
                /*
                    Initiate the 2 vector value
                */
                vec3 v = {random_number_double(1), random_number_double(1), random_number_double(1)};
                vec3 w = {random_number_double(1), random_number_double(1), random_number_double(1)};
                std::cout << "The " << i << "-th vector v is: " << v.x << ", " << v.y << ", " << v.z << "\n";
                std::cout << "The " << i << "-th vector v is: " << w.x << ", " << w.y << ", " << w.z << "\n";
                /*
                    Create the vertex
                */
                vertex ve = {v, w, i};

                /*
                    Assign the vertex
                */
                tetrahedron[i] = ve;
            }

        /*
            2. Start Extracting The Curves 
        */
            /*
                Generate Matrix A and Matrix B
            */
            double ** arr_A = new double*[3];
            for(int i = 0; i < 3; i++)
            {
                arr_A[i] = new double[3];
            }


            double ** arr_B = new double*[3];
            for(int i = 0; i < 3; i++)
            {
                arr_B[i] = new double[3];
            }

            // Init A & B
            get_matrix_A(arr_A, tetrahedron);
            get_matrix_B(arr_B, tetrahedron);

            /*
                For each Triangular Faces
            */
            std::vector<double> record_lamda;
            std::vector<vec3> record_eigen_vector;
            std::vector<int> record_face_indx;
            bool need_recorded = false;
            for(int i = 0; i < cellFaceNum; i++)
            {
                /*
                    Calculate all Root of Pi(lamda) where i is the index of faces 
                */
                double lamda[4];
                calculate_numerator_denominator_root(lamda, i, arr_A, arr_B, tetrahedron);
                
                /*
                    Calculate All Eigenvector for each lamda
                */
                vec3 eigen_vector_arr[3];
                if(lamda[0] == 3)
                {
                    /* 
                        Solve for the three eigen vector
                    */
                    for(int j = 0; j < 3; j++)
                    {
                        bool temp_need_recorded = solve_eigen_vector(tetrahedron, i, lamda[j + 1], eigen_vector_arr, j);
                        need_recorded = temp_need_recorded || need_recorded;
                    }
                }else
                {
                    /*
                        Solve for the only eigen vector
                    */
                    bool temp_need_recorded = solve_eigen_vector(tetrahedron, i, lamda[1], eigen_vector_arr, 0);
                    need_recorded = temp_need_recorded || need_recorded;
                }
                fill_record_lamda(record_lamda, lamda);
                fill_record_eigen_vector(record_eigen_vector, eigen_vector_arr, lamda[0]);    
            }
            
            if(!need_recorded)
            {
                record_lamda.clear();
                record_eigen_vector.clear();
            }

    /* Compute Pass 2 */
    if(record_lamda.size() != 0)
    {
        // Calculate All Roots Of Q(lamda)
        double q_roots[4] = {0, 0, 0, 0};
        double q_index = 4;
        calculate_numerator_denominator_root(q_roots, q_index, arr_A, arr_B, tetrahedron);

        // Collects All Roots Of P(lamda) and Q(lamda)
        collect_all_lamda(record_lamda, q_roots);
        // Sort all roots
        sort_all_lamda_ascending(record_lamda);
        // create all intervals
        std::vector<std::pair<double, double>> all_interval = create_all_intervals(record_lamda);
        // For all intervals, check if equality is satisfied for the interval, append the interval to solution
        std::vector<std::pair<double, double>> solution_intervals = get_solution_intervals(all_interval, arr_A, arr_B, tetrahedron);

        if(solution_intervals.size() != 0){
        /*  1. Sample The lamda 
            2. To Barycentric 
            3. Then To Cartesian
            4. Finally Write To .txt File
        */
        // 1. Sample lamdas from solution intervals
        std::vector<double> lamda_arr;
        sample_lamda(solution_intervals, lamda_arr);

        // 2. Calculate the Barycentric Based On the Barycentric
        std::vector<vec4> barycentrics_arr;
        get_barycentrics_vector(lamda_arr, barycentrics_arr, arr_A, arr_B, tetrahedron);

        // 3. Translate To Cartesian
        std::vector<vec3> cartesians_arr;
        translate_barycentric_to_cartesian(barycentrics_arr, cartesians_arr);

        // 4. Write to txt file
        write_vec3_to_file(cartesians_arr);
        }
    }
    else
    {
        std::cout << "There are no solution intervals\n";
    }

    
    
}
