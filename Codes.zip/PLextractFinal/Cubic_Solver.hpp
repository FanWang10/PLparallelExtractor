#ifndef CUBIC_SOLVER
#define CUBIC_SOLVER
#include <math.h>

void solve_cubic(double* x, double a, double b, double c, double d);

#endif