#include "Matrix_Calculation.hpp"

double get_determinant_3(double ** mat)
{
    return    mat[0][0] * (mat[1][1] * mat[2][2] - mat[1][2] * mat[2][1])
            - mat[0][1] * (mat[1][0] * mat[2][2] - mat[1][2] * mat[2][0])
            + mat[0][2] * (mat[1][0] * mat[2][1] - mat[2][0] * mat[1][1]); 
}

void get_inverse_3(double ** mat, double ** mat_inv)
{
    double det = get_determinant_3(mat);
    if(det == 0){det += 10e-5;}
    double invdet = 1.0 / det;

    mat_inv[0][0] = invdet * ((mat[1][1] * mat[2][2]) - (mat[2][1] * mat[1][2]));
    mat_inv[0][1] = invdet * ((mat[0][2] * mat[2][1]) - (mat[0][1] * mat[2][2]));
    mat_inv[0][2] = invdet * ((mat[0][1] * mat[1][2]) - (mat[0][2] * mat[1][1]));

    mat_inv[1][0] = invdet * ((mat[1][2] * mat[2][0]) - (mat[1][0] * mat[2][2]));
    mat_inv[1][1] = invdet * ((mat[0][0] * mat[2][2]) - (mat[0][2] * mat[2][0]));
    mat_inv[1][2] = invdet * ((mat[1][0] * mat[0][2]) - (mat[0][0] * mat[1][2]));

    mat_inv[2][0] = invdet * ((mat[1][0] * mat[2][1]) - (mat[2][0] * mat[1][1]));
    mat_inv[2][1] = invdet * ((mat[2][0] * mat[0][1]) - (mat[0][0] * mat[2][1]));
    mat_inv[2][2] = invdet * ((mat[0][0] * mat[1][1]) - (mat[1][0] * mat[0][1]));
}


void mat_3_multiply(double ** a, double ** b, double ** result)
{
    for(int i = 0; i < 3; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            for(int u = 0; u < 3; u++)
            {
                result[i][j] += a[i][u] * b[u][j];
            }
        }
    }
}

void mat_multiply_vec_3x3(double ** mat, double * vec)
{
    double v0 = mat[0][0] * vec[0] + mat[0][1] * vec[1] + mat[0][2] * vec[2];
    double v1 = mat[1][0] * vec[0] + mat[1][1] * vec[1] + mat[1][2] * vec[2];
    double v2 = mat[2][0] * vec[0] + mat[2][1] * vec[1] + mat[2][2] * vec[2];
    vec[0] = v0;
    vec[1] = v1;
    vec[2] = v2;
}