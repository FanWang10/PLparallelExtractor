#ifndef PL_EXTRACT_HPP
#define PL_EXTRACT_HPP
#include "type.hpp"
#include <vector>
#include <algorithm>
#include <utility>   
#include "Cubic_Solver.hpp"
#include "Linear_Solver.hpp"
#include "Random_Generator.hpp"
#include "Matrix_Calculation.hpp"
#include "PL_Extract.hpp"
#include "Inverse_Power_Iteration.hpp"
#include <math.h>

void get_matrix_A(double ** A, vertex * tetrahedron);

void get_matrix_B(double ** B, vertex * tetrahedron);

double get_P0_a(double ** B, vertex * tetrahedron);

double get_P0_b(double ** A, double ** B, vertex * tetrahedron);

double get_P0_c(double ** A, double ** B, vertex * tetrahedron);

double get_P0_d(double ** A, double ** B, vertex * tetrahedron);

double get_P1_a(double ** B, vertex * tetrahedron);

double get_P1_b(double ** A, double ** B, vertex * tetrahedron);

double get_P1_c(double ** A, double ** B, vertex * tetrahedron);

double get_P1_d(double ** A, double ** B, vertex * tetrahedron);

double get_P2_a(double ** B, vertex * tetrahedron);

double get_P2_b(double ** A, double ** B, vertex * tetrahedron);

double get_P2_c(double ** A, double ** B, vertex * tetrahedron);

double get_P2_d(double ** A, double ** B, vertex * tetrahedron);

double get_Q_a(double ** B);

double get_Q_b(double ** A, double ** B);

double get_Q_c(double ** A, double ** B);

double get_Q_d(double ** A);

double get_P3_a(double aq, double a0, double a1, double a2);

double get_P3_b(double bq, double b0, double b1, double b2);

double get_P3_c(double cq, double c0, double c1, double c2);

double get_P3_d(double dq, double d0, double d1, double d2);

void calculate_numerator_denominator_root(double * x, int index, double ** A, double ** B, vertex * tetrahedron);

double calculate_numerator_denominator_value(double input_lamda, int index, double ** A, double **B, vertex * tetrahedron);

void calculate_B_inverse_times_A_Peikert_Roth(double ** mat, vertex * tetrahedron, int face_indx, double eigen_value);

bool solve_eigen_vector(vertex * tetrahedron, int face_indx, double eigen_value, vec3 * eigen_vec_arr, int arr_indx);

void fill_record_lamda(std::vector<double> & record, double * lamda);

void fill_record_eigen_vector(std::vector<vec3> & record, vec3 * eigenvec, int num_of_eigenvec);

void collect_all_lamda(std::vector<double> & lamda_record, double * q_lamda);

bool less_than(int i, int j);

void sort_all_lamda_ascending(std::vector<double> & lamda_record);

std::vector<std::pair<double, double>> create_all_intervals(std::vector<double> & lamda_record);

bool P_over_Q_positive_less_than_one(std::pair<double, double> intervals, double ** A, double ** B, vertex * tetrahedron);

std::vector<std::pair<double, double>> get_solution_intervals(std::vector<std::pair<double, double>> & all_intervals, double ** A, double ** B, vertex * tetrahedron);

void Verify(int sample_num, std::pair<double, double> & interval, double ** A, double ** B, vertex * tetrahedron);

void sample_lamda(std::vector<std::pair<double, double>> & solution_intervals, std::vector<double> & lamda);

void get_barycentrics_vector(std::vector<double> & lamdas, std::vector<vec4> & barycentrics, double ** A, double ** B, vertex * tetrahedron);
#endif