#ifndef LINEAR_SOLVER_HPP
#define LINEAR_SOLVER_HPP
#include <math.h> 
#include <iostream>

void compute_lu_decomp(double ** A, double ** L, double ** U, int n);

void solve_lu(double ** L, double ** U, double * b, double * x, int n);

void solve_linear_system(double ** A, double * b, int n, double* x);



#endif