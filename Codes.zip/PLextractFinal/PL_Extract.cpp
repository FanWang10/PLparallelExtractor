#include "PL_Extract.hpp"

void get_matrix_A(double ** A, vertex * tetrahedron)
{
    A[0][0] = tetrahedron[0].v.x - tetrahedron[3].v.x;
    A[0][1] = tetrahedron[1].v.x - tetrahedron[3].v.x;
    A[0][2] = tetrahedron[2].v.x - tetrahedron[3].v.x;

    A[1][0] = tetrahedron[0].v.y - tetrahedron[3].v.y;
    A[1][1] = tetrahedron[1].v.y - tetrahedron[3].v.y;
    A[1][2] = tetrahedron[2].v.y - tetrahedron[3].v.y;

    A[2][0] = tetrahedron[0].v.z - tetrahedron[3].v.z;
    A[2][1] = tetrahedron[1].v.z - tetrahedron[3].v.z;
    A[2][2] = tetrahedron[2].v.z - tetrahedron[3].v.z;
}

void get_matrix_B(double ** B, vertex * tetrahedron)
{
    B[0][0] = tetrahedron[0].w.x - tetrahedron[3].w.x;
    B[0][1] = tetrahedron[1].w.x - tetrahedron[3].w.x;
    B[0][2] = tetrahedron[2].w.x - tetrahedron[3].w.x;

    B[1][0] = tetrahedron[0].w.y - tetrahedron[3].w.y;
    B[1][1] = tetrahedron[1].w.y - tetrahedron[3].w.y;
    B[1][2] = tetrahedron[2].w.y - tetrahedron[3].w.y;

    B[2][0] = tetrahedron[0].w.z - tetrahedron[3].w.z;
    B[2][1] = tetrahedron[1].w.z - tetrahedron[3].w.z;
    B[2][2] = tetrahedron[2].w.z - tetrahedron[3].w.z;
}

double get_P0_a(double ** B, vertex * tetrahedron)
{
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;
    double a0 = -1.0 * ((-1.0 * w3x * (B[1][1] * B[2][2] - B[1][2] * B[2][1])) 
                - (w3y * (B[2][1] * B[0][2] - B[0][1] * B[2][2]))
                - (w3z * (B[0][1] * B[1][2] - B[1][1] * B[0][2])));
    return a0;
}

double get_P0_b(double ** A, double ** B, vertex * tetrahedron)
{
    double v3x = tetrahedron[3].v.x;
    double v3y = tetrahedron[3].v.y;
    double v3z = tetrahedron[3].v.z;
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;
    double b0 =  -1.0 *((v3x * (B[1][1] * B[2][2] - B[1][2] * B[2][1]))
                - (w3x * (A[1][2] * B[2][1] + A[2][1] * B[1][2] - A[1][1] * B[2][2] - A[2][2] * B[1][1]))
                + (v3y * (B[2][1] * B[0][2] - B[0][1] * B[2][2]))
                - (w3y * (A[0][1] * B[2][2] + A[2][2] * B[0][1] - A[0][2] * B[2][1] - A[2][1] * B[0][2]))
                + (v3z * (B[0][1] * B[1][2] - B[1][1] * B[0][2]))
                - (w3z * (A[0][2] * B[1][1] + A[1][1] * B[0][2] - A[0][1] * B[1][2] - A[1][2] * B[0][1])));
    return b0;
}

double get_P0_c(double ** A, double ** B, vertex * tetrahedron)
{
    double v3x = tetrahedron[3].v.x;
    double v3y = tetrahedron[3].v.y;
    double v3z = tetrahedron[3].v.z;
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double c0 =    -1.0 *((v3x * (A[1][2] * B[2][1] + A[2][1] * B[1][2] - A[1][1] * B[2][2] - A[2][2] * B[1][1]))
                - (w3x * (A[1][1] * A[2][2] - A[1][2] * A[2][1]))
                + (v3y * (A[0][1] * B[2][2] + A[2][2] * B[0][1] - A[0][2] * B[2][1] - A[2][1] * B[0][2]))
                - (w3y * (A[0][2] * A[2][1] - A[0][1] * A[2][2]))
                + (v3z * (A[0][2] * B[1][1] + A[1][1] * B[0][2] - A[0][1] * B[1][2] - A[1][2] * B[0][1]))
                - (w3z * (A[0][1] * A[1][2] - A[0][2] * A[1][1])));
 
    return c0;
}

double get_P0_d(double ** A, double ** B, vertex * tetrahedron)
{
    double v3x = tetrahedron[3].v.x;
    double v3y = tetrahedron[3].v.y;
    double v3z = tetrahedron[3].v.z;
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double d0 =    -1.0 *((v3x * (A[1][1] * A[2][2] - A[1][2] * A[2][1]))
                + (v3y * (A[0][2] * A[2][1] - A[0][1] * A[2][2]))
                + (v3z * (A[0][1] * A[1][2] - A[0][2] * A[1][1])));

    return d0;
}

double get_P1_a(double ** B, vertex * tetrahedron)
{
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double a1 = -1.0 *((-1.0 * w3x * (B[1][2] * B[2][0] - B[1][0] * B[2][2])) 
                - (w3y * (B[0][0] * B[2][2] - B[0][2] * B[2][0]))
                - (w3z * (B[0][2] * B[1][0] - B[0][0] * B[1][2])));

    return a1;
}

double get_P1_b(double ** A, double ** B, vertex * tetrahedron)
{
    double v3x = tetrahedron[3].v.x;
    double v3y = tetrahedron[3].v.y;
    double v3z = tetrahedron[3].v.z;
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double b1 =    -1.0 *((v3x * (B[1][2] * B[2][0] - B[1][0] * B[2][2]))
                    - (w3x * (A[1][0] * B[2][2] + A[2][2] * B[1][0] - A[1][2] * B[2][0] - A[2][0] * B[1][2]))
                    + (v3y * (B[0][0] * B[2][2] - B[0][2] * B[2][0]))
                    - (w3y * (A[0][2] * B[2][0] + A[2][0] * B[0][2] - A[0][0] * B[2][2] - A[2][2] * B[0][0]))
                    + (v3z * (B[0][2] * B[1][0] - B[0][0] * B[1][2]))
                    - (w3z * (A[0][0] * B[1][2] + A[1][2] * B[0][0] - A[0][2] * B[1][0] - A[1][0] * B[0][2])));

    return b1;
}

double get_P1_c(double ** A, double ** B, vertex * tetrahedron)
{
    double v3x = tetrahedron[3].v.x;
    double v3y = tetrahedron[3].v.y;
    double v3z = tetrahedron[3].v.z;
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double c1 =    -1.0 *((v3x * (A[1][0] * B[2][2] + A[2][2] * B[1][0] - A[1][2] * B[2][0] - A[2][0] * B[1][2]))
                    - (w3x * (A[1][2] * A[2][0] - A[1][0] * A[2][2]))
                    + (v3y * (A[0][2] * B[2][0] + A[2][0] * B[0][2] - A[0][0] * B[2][2] - A[2][2] * B[0][0]))
                    - (w3y * (A[0][0] * A[2][2] - A[0][2] * A[2][0]))
                    + (v3z * (A[0][0] * B[1][2] + A[1][2] * B[0][0] - A[0][2] * B[1][0] - A[1][0] * B[0][2]))
                    - (w3z * (A[0][2] * A[1][0] - A[0][0] * A[1][2])));

    return c1;
}

double get_P1_d(double ** A, double ** B, vertex * tetrahedron)
{
    double v3x = tetrahedron[3].v.x;
    double v3y = tetrahedron[3].v.y;
    double v3z = tetrahedron[3].v.z;
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double d1 =    -1.0 *((v3x * (A[1][2] * A[2][0] - A[1][0] * A[2][2]))
                    + (v3y * (A[0][0] * A[2][2] - A[0][2] * A[2][0]))
                    + (v3z * (A[0][2] * A[1][0] - A[0][0] * A[1][2])));
    
    return d1;
}

double get_P2_a(double ** B, vertex * tetrahedron)
{
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double a2 = -1.0 *((-1.0 * w3x * (B[1][0] * B[2][1] - B[1][1] * B[2][0])) 
                    - (w3y * (B[0][1] * B[2][0] - B[0][0] * B[2][1]))
                    - (w3z * (B[0][0] * B[1][1] - B[0][1] * B[1][0])));

    return a2;
}

double get_P2_b(double ** A, double ** B, vertex * tetrahedron)
{
    double v3x = tetrahedron[3].v.x;
    double v3y = tetrahedron[3].v.y;
    double v3z = tetrahedron[3].v.z;
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double b2 =    -1.0 *((v3x * (B[1][0] * B[2][1] - B[1][1] * B[2][0]))
                    - (w3x * (A[1][1] * B[2][0] + A[2][0] * B[1][1] - A[1][0] * B[2][1] - A[2][1] * B[1][0]))
                    + (v3y * (B[0][1] * B[2][0] - B[0][0] * B[2][1]))
                    - (w3y * (A[0][0] * B[2][1] + A[2][1] * B[0][0] - A[2][0] * B[0][1] - A[0][1] * B[2][0]))
                    + (v3z * (B[0][0] * B[1][1] - B[0][1] * B[1][0]))
                    - (w3z * (A[0][1] * B[1][0] + A[1][0] * B[0][1] - A[0][0] * B[1][1] - A[1][1] * B[0][0])));

    return b2;
}

double get_P2_c(double ** A, double ** B, vertex * tetrahedron)
{
    double v3x = tetrahedron[3].v.x;
    double v3y = tetrahedron[3].v.y;
    double v3z = tetrahedron[3].v.z;
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double c2 =    -1.0 *((v3x * (A[1][1] * B[2][0] + A[2][0] * B[1][1] - A[1][0] * B[2][1] - A[2][1] * B[1][0]))
                    - (w3x * (A[1][0] * A[2][1] - A[1][1] * A[2][0]))
                    + (v3y * (A[0][0] * B[2][1] + A[2][1] * B[0][0] - A[2][0] * B[0][1] - A[0][1] * B[2][0]))
                    - (w3y * (A[0][1] * A[2][0] - A[0][0] * A[2][1]))
                    + (v3z * (A[0][1] * B[1][0] + A[1][0] * B[0][1] - A[0][0] * B[1][1] - A[1][1] * B[0][0]))
                    - (w3z * (A[0][0] * A[1][1] - A[0][1] * A[1][0])));

    return c2;
}

double get_P2_d(double ** A, double ** B, vertex * tetrahedron)
{
    double v3x = tetrahedron[3].v.x;
    double v3y = tetrahedron[3].v.y;
    double v3z = tetrahedron[3].v.z;
    double w3x = tetrahedron[3].w.x;
    double w3y = tetrahedron[3].w.y;
    double w3z = tetrahedron[3].w.z;

    double d2 =    -1.0 *((v3x * (A[1][0] * A[2][1] - A[1][1] * A[2][0]))
                    + (v3y * (A[0][1] * A[2][0] - A[0][0] * A[2][1]))
                    + (v3z * (A[0][0] * A[1][1] - A[0][1] * A[1][0])));

    return d2;
}

double get_Q_a(double ** B)
{
    double aq = -1.0 * get_determinant_3(B);

    return aq;
}

double get_Q_b(double ** A, double ** B)
{
    double **mat_q_b_1 = new double *[3];
    for(int i = 0; i < 3; i++)
    {
        mat_q_b_1[i] = new double[3];
    }
    mat_q_b_1[0][0] = A[0][0];
    mat_q_b_1[0][1] = B[0][1];
    mat_q_b_1[0][2] = B[0][2];
    mat_q_b_1[1][0] = A[1][0];
    mat_q_b_1[1][1] = B[1][1];
    mat_q_b_1[1][2] = B[1][2];
    mat_q_b_1[2][0] = A[2][0];
    mat_q_b_1[2][1] = B[2][1];
    mat_q_b_1[2][2] = B[2][2];

    double **mat_q_b_2 = new double *[3];
    for(int i = 0; i < 3; i++)
    {
        mat_q_b_2[i] = new double[3];
    }
    mat_q_b_2[0][0] = B[0][0];
    mat_q_b_2[0][1] = A[0][1];
    mat_q_b_2[0][2] = B[0][2];
    mat_q_b_2[1][0] = B[1][0];
    mat_q_b_2[1][1] = A[1][1];
    mat_q_b_2[1][2] = B[1][2];
    mat_q_b_2[2][0] = B[2][0];
    mat_q_b_2[2][1] = A[2][1];
    mat_q_b_2[2][2] = B[2][2];

    double **mat_q_b_3 = new double *[3];
    for(int i = 0; i < 3; i++)
    {
        mat_q_b_3[i] = new double[3];
    }
    mat_q_b_3[0][0] = B[0][0];
    mat_q_b_3[0][1] = B[0][1];
    mat_q_b_3[0][2] = A[0][2];
    mat_q_b_3[1][0] = B[1][0];
    mat_q_b_3[1][1] = B[1][1];
    mat_q_b_3[1][2] = A[1][2];
    mat_q_b_3[2][0] = B[2][0];
    mat_q_b_3[2][1] = B[2][1];
    mat_q_b_3[2][2] = A[2][2];

    double bq = get_determinant_3(mat_q_b_1) + get_determinant_3(mat_q_b_2) + get_determinant_3(mat_q_b_3);

    return bq;
}

double get_Q_c(double ** A, double ** B)
{
    double **mat_q_c_1 = new double *[3];
    for(int i = 0; i < 3; i++)
    {
        mat_q_c_1[i] = new double[3];
    }
    mat_q_c_1[0][0] = A[0][0];
    mat_q_c_1[0][1] = A[0][1];
    mat_q_c_1[0][2] = B[0][2];
    mat_q_c_1[1][0] = A[1][0];
    mat_q_c_1[1][1] = A[1][1];
    mat_q_c_1[1][2] = B[1][2];
    mat_q_c_1[2][0] = A[2][0];
    mat_q_c_1[2][1] = A[2][1];
    mat_q_c_1[2][2] = B[2][2];

    double **mat_q_c_2 = new double *[3];
    for(int i = 0; i < 3; i++)
    {
        mat_q_c_2[i] = new double[3];
    }
    mat_q_c_2[0][0] = A[0][0];
    mat_q_c_2[0][1] = B[0][1];
    mat_q_c_2[0][2] = A[0][2];
    mat_q_c_2[1][0] = A[1][0];
    mat_q_c_2[1][1] = B[1][1];
    mat_q_c_2[1][2] = A[1][2];
    mat_q_c_2[2][0] = A[2][0];
    mat_q_c_2[2][1] = B[2][1];
    mat_q_c_2[2][2] = A[2][2];

    double **mat_q_c_3 = new double *[3];
    for(int i = 0; i < 3; i++)
    {
        mat_q_c_3[i] = new double[3];
    }
    mat_q_c_3[0][0] = B[0][0];
    mat_q_c_3[0][1] = A[0][1];
    mat_q_c_3[0][2] = A[0][2];
    mat_q_c_3[1][0] = B[1][0];
    mat_q_c_3[1][1] = A[1][1];
    mat_q_c_3[1][2] = A[1][2];
    mat_q_c_3[2][0] = B[2][0];
    mat_q_c_3[2][1] = A[2][1];
    mat_q_c_3[2][2] = A[2][2];

    double cq = -1.0 * (get_determinant_3(mat_q_c_1) + get_determinant_3(mat_q_c_2) + get_determinant_3(mat_q_c_3));
 
    return cq;
}

double get_Q_d(double ** A)
{
    double dq = get_determinant_3(A);

    return dq;
}

double get_P3_a(double aq, double a0, double a1, double a2)
{
    double a3 = aq - a0 - a1 - a2;

    return a3; 
}

double get_P3_b(double bq, double b0, double b1, double b2)
{
    double b3 = bq - b0 - b1 - b2;

    return b3;
}

double get_P3_c(double cq, double c0, double c1, double c2)
{
    double c3 = cq - c0 - c1 - c2;

    return c3;
}

double get_P3_d(double dq, double d0, double d1, double d2)
{
    double d3 = dq - d0 - d1 - d2;

    return d3;
}

void calculate_numerator_denominator_root(double * x, int index, double ** A, double ** B, vertex * tetrahedron)
{
    double a0 = get_P0_a(B, tetrahedron);
    double b0 = get_P0_b(A, B, tetrahedron);
    double c0 = get_P0_c(A, B, tetrahedron);
    double d0 = get_P0_d(A, B, tetrahedron);

    double a1 = get_P1_a(B, tetrahedron);
    double b1 = get_P1_b(A, B, tetrahedron);
    double c1 = get_P1_c(A, B, tetrahedron);
    double d1 = get_P1_d(A, B, tetrahedron);

    double a2 = get_P2_a(B, tetrahedron);
    double b2 = get_P2_b(A, B, tetrahedron);
    double c2 = get_P2_c(A, B, tetrahedron);
    double d2 = get_P2_d(A, B, tetrahedron);

    double aq = get_Q_a(B);
    double bq = get_Q_b(A, B);
    double cq = get_Q_c(A, B);
    double dq = get_Q_d(A);

    double a3 = get_P3_a(aq, a0, a1, a2);
    double b3 = get_P3_b(bq, b0, b1, b2);
    double c3 = get_P3_c(cq, c0, c1, c2);
    double d3 = get_P3_d(dq, d0, d1, d2);

    if(index == 0)
    {
        /* Get The Roots Of P0(lamda) */
        solve_cubic(x, a0, b0, c0, d0);
    }
    else if(index == 1)
    {
        /* Get The Roots Of P1(lamda) */

        solve_cubic(x, a1, b1, c1, d1);
    }
    else if(index == 2)
    {
        /* Get The Roots Of P2(lamda) */

        solve_cubic(x, a2, b2, c2, d2);
    }
    else if(index == 3)
    {
        /* Get The Roots Of P3(lamda)*/
        solve_cubic(x, a3, b3, c3, d3);
    }else
    {
        /* Get all the coefficient of Q(lamda) */
        solve_cubic(x, aq, bq, cq, dq);
    }
}

double calculate_numerator_denominator_value(double input_lamda, int index, double ** A, double **B, vertex * tetrahedron)
{
    double a0 = get_P0_a(B, tetrahedron);
    double b0 = get_P0_b(A, B, tetrahedron);
    double c0 = get_P0_c(A, B, tetrahedron);
    double d0 = get_P0_d(A, B, tetrahedron);

    double a1 = get_P1_a(B, tetrahedron);
    double b1 = get_P1_b(A, B, tetrahedron);
    double c1 = get_P1_c(A, B, tetrahedron);
    double d1 = get_P1_d(A, B, tetrahedron);

    double a2 = get_P2_a(B, tetrahedron);
    double b2 = get_P2_b(A, B, tetrahedron);
    double c2 = get_P2_c(A, B, tetrahedron);
    double d2 = get_P2_d(A, B, tetrahedron);

    double aq = get_Q_a(B);
    double bq = get_Q_b(A, B);
    double cq = get_Q_c(A, B);
    double dq = get_Q_d(A);

    double a3 = get_P3_a(aq, a0, a1, a2);
    double b3 = get_P3_b(bq, b0, b1, b2);
    double c3 = get_P3_c(cq, c0, c1, c2);
    double d3 = get_P3_d(dq, d0, d1, d2);
    double polynomial_value = 0;

    if(index == 0)
    {
        /* Get The values Of P0(lamda) */
        polynomial_value = a0 * input_lamda * input_lamda * input_lamda + b0 * input_lamda * input_lamda + c0 * input_lamda + d0;
    }
    else if(index == 1)
    {
        /* Get The values Of P1(lamda) */
        polynomial_value = a1 * input_lamda * input_lamda * input_lamda + b1 * input_lamda * input_lamda + c1 * input_lamda + d1;

    }
    else if(index == 2)
    {
        /* Get The values Of P2(lamda) */
        polynomial_value = a2 * input_lamda * input_lamda * input_lamda + b2 * input_lamda * input_lamda + c2 * input_lamda + d2;

    }
    else if(index == 3)
    {
        /* Get The values Of P3(lamda)*/
        polynomial_value = a3 * input_lamda * input_lamda * input_lamda + b3 * input_lamda * input_lamda + c3 * input_lamda + d3;

    }else
    {
        /* Get all the values of Q(lamda) */
        polynomial_value = aq * input_lamda * input_lamda * input_lamda + bq * input_lamda * input_lamda + cq * input_lamda + dq;

    }
    return polynomial_value;

}

void calculate_B_inverse_times_A_Peikert_Roth(double ** mat, vertex * tetrahedron, int face_indx, double eigen_value)
{
    double **A = new double*[3];
    for(int i = 0; i < 3; i++)
    {
        A[i] = new double[3];
    }

    double **B = new double*[3];
    for(int i = 0; i < 3; i++)
    {
        B[i] = new double[3];
    }

    double ** B_inverse = new double*[3];
    for(int i = 0; i < 3; i++)
    {
        B_inverse[i] = new double[3];
    }

    double **A_B_product = new double*[3];
    for(int i = 0; i < 3; i++)
    {
        A_B_product[i] = new double[3];
    }

    if(face_indx == 0)
    {
        /* Point: v1 w1 v2 w2 v3 w3*/
        A[0][0] = tetrahedron[1].v.x;
        A[0][1] = tetrahedron[2].v.x;
        A[0][2] = tetrahedron[3].v.x;

        A[1][0] = tetrahedron[1].v.y;
        A[1][1] = tetrahedron[2].v.y;
        A[1][2] = tetrahedron[3].v.y;

        A[2][0] = tetrahedron[1].v.z;
        A[2][1] = tetrahedron[2].v.z;
        A[2][2] = tetrahedron[3].v.z;

        B[0][0] = tetrahedron[1].w.x;
        B[0][1] = tetrahedron[2].w.x;
        B[0][2] = tetrahedron[3].w.x;

        B[1][0] = tetrahedron[1].w.y;
        B[1][1] = tetrahedron[2].w.y;
        B[1][2] = tetrahedron[3].w.y;

        B[2][0] = tetrahedron[1].w.z;
        B[2][1] = tetrahedron[2].w.z;
        B[2][2] = tetrahedron[3].w.z;
    }
    else if(face_indx == 1)
    {
        /* Point: v0 w0 v2 w2 v3 w3*/
        A[0][0] = tetrahedron[0].v.x;
        A[0][1] = tetrahedron[2].v.x;
        A[0][2] = tetrahedron[3].v.x;

        A[1][0] = tetrahedron[0].v.y;
        A[1][1] = tetrahedron[2].v.y;
        A[1][2] = tetrahedron[3].v.y;

        A[2][0] = tetrahedron[0].v.z;
        A[2][1] = tetrahedron[2].v.z;
        A[2][2] = tetrahedron[3].v.z;

        B[0][0] = tetrahedron[0].w.x;
        B[0][1] = tetrahedron[2].w.x;
        B[0][2] = tetrahedron[3].w.x;

        B[1][0] = tetrahedron[0].w.y;
        B[1][1] = tetrahedron[2].w.y;
        B[1][2] = tetrahedron[3].w.y;

        B[2][0] = tetrahedron[0].w.z;
        B[2][1] = tetrahedron[2].w.z;
        B[2][2] = tetrahedron[3].w.z;
    }
    else if(face_indx == 2)
    {
        /* Point: v0 w0 v1 w1 v3 w3*/
        A[0][0] = tetrahedron[0].v.x;
        A[0][1] = tetrahedron[1].v.x;
        A[0][2] = tetrahedron[3].v.x;

        A[1][0] = tetrahedron[0].v.y;
        A[1][1] = tetrahedron[1].v.y;
        A[1][2] = tetrahedron[3].v.y;

        A[2][0] = tetrahedron[0].v.z;
        A[2][1] = tetrahedron[1].v.z;
        A[2][2] = tetrahedron[3].v.z;

        B[0][0] = tetrahedron[0].w.x;
        B[0][1] = tetrahedron[1].w.x;
        B[0][2] = tetrahedron[3].w.x;

        B[1][0] = tetrahedron[0].w.y;
        B[1][1] = tetrahedron[1].w.y;
        B[1][2] = tetrahedron[3].w.y;

        B[2][0] = tetrahedron[0].w.z;
        B[2][1] = tetrahedron[1].w.z;
        B[2][2] = tetrahedron[3].w.z;
    }
    else
    {
        /* Point: v0 w0 v1 w1 v2 w2 */
        A[0][0] = tetrahedron[0].v.x;
        A[0][1] = tetrahedron[1].v.x;
        A[0][2] = tetrahedron[2].v.x;

        A[1][0] = tetrahedron[0].v.y;
        A[1][1] = tetrahedron[1].v.y;
        A[1][2] = tetrahedron[2].v.y;

        A[2][0] = tetrahedron[0].v.z;
        A[2][1] = tetrahedron[1].v.z;
        A[2][2] = tetrahedron[2].v.z;

        B[0][0] = tetrahedron[0].w.x;
        B[0][1] = tetrahedron[1].w.x;
        B[0][2] = tetrahedron[2].w.x;

        B[1][0] = tetrahedron[0].w.y;
        B[1][1] = tetrahedron[1].w.y;
        B[1][2] = tetrahedron[2].w.y;

        B[2][0] = tetrahedron[0].w.z;
        B[2][1] = tetrahedron[1].w.z;
        B[2][2] = tetrahedron[2].w.z;
    }

    get_inverse_3(B, B_inverse);
    mat_3_multiply(B_inverse, A, A_B_product);
    for(int i = 0; i < 3; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            mat[i][j] = A_B_product[i][j];
        }
    }
}

bool solve_eigen_vector(vertex * tetrahedron, int face_indx, double eigen_value, vec3 * eigen_vec_arr, int arr_indx)
{
    bool need_recorded = false;

    /* Initialize A' - eigen_value * B' */
    double ** coefficient_mat = new double *[3];
    for(int i = 0; i < 3; i++)
    {
        coefficient_mat[i] = new double [3];
    }

    calculate_B_inverse_times_A_Peikert_Roth(coefficient_mat, tetrahedron, face_indx, eigen_value);

    /* Solve For Eigen_vector*/
    double eigen_vec[3] = {0, 0, 0};
    //inverse_power_iteration_3x3(double ** A, double eigenvalue, double * eigenvector)
    inverse_power_iteration_3x3(coefficient_mat, eigen_value, eigen_vec);

    if((eigen_vec[0] <= 1 && eigen_vec[0] >= 0)
    && (eigen_vec[1] <= 1 && eigen_vec[1] >= 0)
    && (eigen_vec[2] <= 1 && eigen_vec[2] >= 0))
    {
        need_recorded = true;
    }

    eigen_vec_arr[arr_indx] = vec3{eigen_vec[0], eigen_vec[1], eigen_vec[2]};

    //std::cout << "Eigenvec for face = " << face_indx << ", eigenvalue = " << eigen_value << ", is " << eigen_vec_arr[arr_indx].x << ", " << eigen_vec_arr[arr_indx].y << ", " << eigen_vec_arr[arr_indx].z << "\n";

    return need_recorded;
}

void fill_record_lamda(std::vector<double> & record, double * lamda)
{
    int j = 1;
    for(int i = 0; i < lamda[0]; i++)
    {
        record.push_back(lamda[j]);
        j++;
    }
}

void fill_record_eigen_vector(std::vector<vec3> & record, vec3 * eigenvec, int num_of_eigenvec)
{
    for(int i = 0; i < num_of_eigenvec; i++)
    {
        record.push_back(eigenvec[i]);
    }
}

void collect_all_lamda(std::vector<double> & lamda_record, double * q_lamda)
{
    for(int i = 1; i < q_lamda[0]; i++)
    {
        lamda_record.push_back(q_lamda[i]);
    }
}

void sort_all_lamda_ascending(std::vector<double> & lamda_record)
{
    std::sort(lamda_record.begin(), lamda_record.end(), std::less<double>{});

    for(int i = 1; i < lamda_record.size(); i++)
    {
        if(lamda_record.at(i) == lamda_record.at(i - 1))
        {
            lamda_record.erase(lamda_record.begin() + i - 1);
        } 
    }


    std::cout << "Interval is: \n";
    for(int i = 0; i < lamda_record.size(); i++)
    {
        std::cout << lamda_record.at(i) << " ";
    }
    std::cout << "\n";
}

std::vector<std::pair<double, double>> create_all_intervals(std::vector<double> & lamda_record)
{
    std::vector<std::pair<double, double>> solution_intervals;
    std::pair<double, double> pair_1 (-NAN, lamda_record.at(0));
    solution_intervals.push_back(pair_1);
    for(int i = 1; i < lamda_record.size() - 1; i = i + 2)
    {
        std::pair<double, double> pair_n (lamda_record.at(i), lamda_record.at(i + 1));
        solution_intervals.push_back(pair_n);
    }
    std::pair<double, double> pair_2 (lamda_record.at(lamda_record.size() - 1), NAN);
    solution_intervals.push_back(pair_2);
    return solution_intervals;
}

bool P_over_Q_positive_less_than_one(std::pair<double, double> intervals, double ** A, double ** B, vertex * tetrahedron)
{
    double test_value = 0;
    if((!isnan(std::get<0>(intervals))) && (!isnan(std::get<0>(intervals))))
    {
        test_value = (std::get<0>(intervals) + std::get<1>(intervals)) / 2.0;
    }else if(isnan(std::get<0>(intervals)))
    {
        test_value = std::get<1>(intervals) - 0.05;
    }else if(isnan(std::get<1>(intervals)))
    {
        test_value = std::get<1>(intervals) + 0.05;
    }

    double q = calculate_numerator_denominator_value(test_value, 4, A, B, tetrahedron);
    double p0 = calculate_numerator_denominator_value(test_value, 0, A, B, tetrahedron);
    double p1 = calculate_numerator_denominator_value(test_value, 1, A, B, tetrahedron);
    double p2 = calculate_numerator_denominator_value(test_value, 2, A, B, tetrahedron);
    double p3 = calculate_numerator_denominator_value(test_value, 3, A, B, tetrahedron) ;

    return ((p0 / q) >= 0) && ((p0/q) <= 1) 
            && ((p1 / q) >= 0) && ((p1/q) <= 1)
            && ((p2 / q) >= 0) && ((p2/q) <= 1)
            && ((p3 / q) >= 0) && ((p3/q) <= 1);
}

double calculate_angle_degree_between_two_vec3(vec3 & vec1, vec3 & vec2)
{
    double dot_product = vec1.x * vec2.x + vec1.y * vec2.y + vec1.z * vec2.z;
    double vec1_length = sqrt(vec1.x * vec1.x + vec1.y * vec1.y + vec1.z * vec1.z);
    double vec2_length = sqrt(vec2.x * vec2.x + vec2.y * vec2.y + vec2.z * vec2.z);
    double cos_angle = dot_product / (vec1_length * vec2_length);
    double angle_degree = acos(cos_angle) * (180.0 / M_PI);
    return angle_degree;
}

void Verify(int sample_num, std::pair<double, double> & interval, double ** A, double ** B, vertex * tetrahedron)
{
    double test_value = ((std::get<1>(interval) - std::get<0>(interval)) / 6) * sample_num + std::get<0>(interval);
    if(isnan(test_value))
    {
        if(isnan(std::get<0>(interval)))
        {
            test_value = std::get<1>(interval) - sample_num;
        }else if(isnan(std::get<1>(interval)))
        {
            test_value = std::get<0>(interval) + sample_num;
        }
    }
    double p0 = calculate_numerator_denominator_value(test_value, 0, A, B, tetrahedron);
    double p1 = calculate_numerator_denominator_value(test_value, 1, A, B, tetrahedron);
    double p2 = calculate_numerator_denominator_value(test_value, 2, A, B, tetrahedron);
    double p3 = calculate_numerator_denominator_value(test_value, 3, A, B, tetrahedron);
    double q = calculate_numerator_denominator_value(test_value, 4, A, B, tetrahedron);
    double barycentric0 = p0/q;
    double barycentric1 = p1/q;
    double barycentric2 = p2/q;
    double barycentric3 = p3/q;
    vec3 v {barycentric0 * tetrahedron[0].v.x + barycentric1 * tetrahedron[1].v.x + barycentric2 * tetrahedron[2].v.x + barycentric3 * tetrahedron[3].v.x,
            barycentric0 * tetrahedron[0].v.y + barycentric1 * tetrahedron[1].v.y + barycentric2 * tetrahedron[2].v.y + barycentric3 * tetrahedron[3].v.y,
            barycentric0 * tetrahedron[0].v.z + barycentric1 * tetrahedron[1].v.z + barycentric2 * tetrahedron[2].v.z + barycentric3 * tetrahedron[3].v.z};

    vec3 w {barycentric0 * tetrahedron[0].w.x + barycentric1 * tetrahedron[1].w.x + barycentric2 * tetrahedron[2].w.x + barycentric3 * tetrahedron[3].w.x,
            barycentric0 * tetrahedron[0].w.y + barycentric1 * tetrahedron[1].w.y + barycentric2 * tetrahedron[2].w.y + barycentric3 * tetrahedron[3].w.y,
            barycentric0 * tetrahedron[0].w.z + barycentric1 * tetrahedron[1].w.z + barycentric2 * tetrahedron[2].w.z + barycentric3 * tetrahedron[3].w.z};

    double vxw_x = v.y * w.z - v.z * w.y;
    double vxw_y = v.z * w.x - v.x * w.z;
    double vxw_z = v.x * w.y - v.y * w.x;
    std::cout << "For sample lamda: " << test_value <<" v X w is: " << vxw_x << ", " << vxw_y << ", " << vxw_z << "\n"; 
    std::cout << "And the angle in degree between two vectors is: " << calculate_angle_degree_between_two_vec3(v, w) << "\n";
}

std::vector<std::pair<double, double>> get_solution_intervals(std::vector<std::pair<double, double>> & all_intervals, double ** A, double ** B, vertex * tetrahedron)
{
    std::vector<std::pair<double, double>> solution_intervals;
    for(auto interval : all_intervals)
    {
        if(P_over_Q_positive_less_than_one(interval, A, B, tetrahedron))
        {
            solution_intervals.push_back(interval);
        }
    }

    if(solution_intervals.size() == 0)
    {
        std::cout << "There are no solution intervals.\n";
    }

    for(auto interval: solution_intervals)
    {
        std::cout << "Solution intervals: " << std::get<0>(interval) << ", " << std::get<1>(interval) << " \n";
        for(int sample_num = 1; sample_num < 6; sample_num++)
        {
            Verify(sample_num, interval, A, B, tetrahedron);
        }
    }


    return solution_intervals;
}

void sample_lamda(std::vector<std::pair<double, double>> & solution_intervals, std::vector<double> & lamda)
{
    int num_of_sample = 100;
    for(auto pair : solution_intervals)
    {
        double lamda_i;
        if(!isnan(std::get<0>(pair)) && !isnan(std::get<1>(pair)))
        {
            for(int i = 0;i < num_of_sample; i++)
            {
                lamda_i = i * ((std::get<1>(pair) - std::get<0>(pair)) / num_of_sample) + std::get<0>(pair);
                lamda.push_back(lamda_i);
            }

        }else if(isnan(std::get<0>(pair)) && !isnan(std::get<1>(pair)))
        {
            for(int i = 0; i < num_of_sample; i++)
            {
                lamda_i = std::get<1>(pair) - pow(10, i);
                lamda.push_back(lamda_i);
            }

        }else if(!isnan(std::get<0>(pair)) && isnan(std::get<1>(pair)))
        {
            for(int i = 1; i < num_of_sample; i++)
            {
                lamda_i = std::get<0>(pair) * pow(10, i);
                lamda.push_back(lamda_i);
            }
        }
    }
}

// double calculate_numerator_denominator_value(double input_lamda, int index, double ** A, double **B, vertex * tetrahedron);
void get_barycentrics_vector(std::vector<double> & lamdas, std::vector<vec4> & barycentrics, double ** A, double ** B, vertex * tetrahedron)
{
    for(int i = 0; i < lamdas.size(); i++)
    {
        double lamda_i = lamdas.at(i);
        double p0 = calculate_numerator_denominator_value(lamda_i, 0, A, B, tetrahedron);
        double p1 = calculate_numerator_denominator_value(lamda_i, 1, A, B, tetrahedron);
        double p2 = calculate_numerator_denominator_value(lamda_i, 2, A, B, tetrahedron);
        double p3 = calculate_numerator_denominator_value(lamda_i, 3, A, B, tetrahedron);
        double q  = calculate_numerator_denominator_value(lamda_i, 4, A, B, tetrahedron);
        vec4 barycentric_i{p0 / q, p1 / q, p2 / q, p3 / q};
        barycentrics.push_back(barycentric_i);
    }
}