#include "Cubic_Solver.hpp"

void solve_cubic(double* x, double a, double b, double c, double d)
{
    /* a = a / a, b = b / a, c = c / a, d = d / a */
    a = 1;
    b = b / a;
    c = c / a;
    d = d / a;

    /* Calculate Q */
    double q = (b * b - 3.0 * c) / 9.0;

    /* Calculate R */
    double r = ((2.0 * b * b * b) - (9.0 * b * c) + (27.0 * d)) / 54.0;

    /* If Q && R are real(always true here) && R^2 < Q^3, then cubic equation has three real roots */
    if(r * r < q * q * q)
    {
        /* 3 real roots case */
        double theta = acos(r / sqrt(q * q * q));
        
        /* The number of real roots is 3 */
        x[0] = 3;

        /* Calculate x1 */
        x[1] = -2.0 * sqrt(q) * cos(theta / 3.0) - (b / 3.0);
        
        /* Calculate x2 */
        x[2] = -2.0 * sqrt(q) * cos((theta + 2.0 * M_PI) / 3.0) - (b / 3.0);
    
        /* Calculate x3 */
        x[3] = -2.0 * sqrt(q) * cos((theta - 2.0 * M_PI) / 3.0) - (b / 3.0);
    }
    else{
        /* Compute A */
        double A = 0;
        if(r > 0)
        {
            A = (-1.0) * cbrt(fabs(r) + sqrt(r * r - q * q * q)); 
        }else if(r == 0)
        {
            A = 0;
        }else
        {
            A = cbrt(fabs(r) + sqrt(r * r - q * q * q));
        }

        /* Compute B */
        double B = 0;
        if(A != 0)
        {
            B = q / A;
        }

        /* The number of real roots is 1 */
        x[0] = 1;

        /* Compute real root x1 */
        x[1] = (A + B) - (b / 3.0);
    }
}