#include "Inverse_Power_Iteration.hpp"

double compute_delta_inverse_power_iteration_3x3(double * vec, double * preVec)
{
    double diff0 = vec[0] - preVec[0];
    double diff1 = vec[1] - preVec[1];
    double diff2 = vec[2] - preVec[2];
    double delta = sqrt(diff0 * diff0 + diff1 * diff1 + diff2 * diff2);
    return delta;
}

void normalize_vec3(double * vec)
{
    double denom = sqrt(vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2]);
    vec[0] = vec[0] / denom;
    vec[1] = vec[1] / denom;
    vec[2] = vec[2] / denom;
}

// Implementation of the alorithm that will compute the eigen value
void inverse_power_iteration_3x3(double ** A, double eigenvalue, double * eigenvector)
{
    int maxIterations = 100;
    int numRows = 3;

    // Create an random initial vector, v
    for(int i = 0; i < numRows; i++)
    {
        eigenvector[i] = static_cast<double>(random_number_int());
    }

    // Iterate
    int iterationCount = 0;
    double deltaThreshold = 1e-9;
    double delta = 1e6;
    double prevVector[numRows] = {0, 0, 0};
    double ** tempMatrix = new double * [3];
    for(int i = 0; i < numRows; i++)
    {
        tempMatrix[i] = new double[3];
    } 
    double ** tempMatrixInverse = new double * [3];
    for(int i = 0; i < numRows; i++)
    {
        tempMatrixInverse[i] = new double[3];
    }

    while((iterationCount < maxIterations) && (delta > deltaThreshold))
    {
        // Copy current eigenvector to prevVector
        for(int i = 0; i < numRows; i++)
        {
            prevVector[i] = eigenvector[i];
        }

        // Compute the next value of v
        // Compute (A - lamda * I)
        for(int i = 0; i < numRows; i++)
        {
            for(int j = 0; j < numRows; j++)
            {
                if(i == j)
                {
                    tempMatrix[i][j] = A[i][j] - eigenvalue;
                }else{
                    tempMatrix[i][j] = A[i][j];
                }   
            }
        }
        get_inverse_3(tempMatrix, tempMatrixInverse);
        mat_multiply_vec_3x3(tempMatrixInverse, eigenvector);
        normalize_vec3(eigenvector);

        // Compute delta
        delta = compute_delta_inverse_power_iteration_3x3(eigenvector, prevVector);

        // Increment iteration
        iterationCount++;
    }
}