#ifndef DRAW_LINE_HPP
#define DRAW_LINE_HPP
#include "type.hpp"
#include <math.h>
#include <fstream>
#include <vector>

vec3 translate_single_barycentric_to_cartesian(vec4 & barycentric);

void translate_barycentric_to_cartesian(std::vector<vec4> & barycentrics, std::vector<vec3> & cartesians);

void write_vec3_to_file(std::vector<vec3> & vectors);

#endif