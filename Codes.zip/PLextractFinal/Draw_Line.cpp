#include "Draw_Line.hpp"

vec3 translate_single_barycentric_to_cartesian(vec4 & barycentric)
{
    vec3 cartesian{0, 0, 0};
    /* Define the cartesian coordinate of the tetrahedra cell */
    vec3 vertex0 {0.5, 1, sqrt(3)/6.0};
    vec3 vertex1 {0.5, 0, sqrt(3)/2.0};
    vec3 vertex2 {1, 0, 0};
    vec3 vertex3 {0, 0, 0};

    /* Translate */
    cartesian.x = barycentric.a * vertex0.x + barycentric.b * vertex1.x + barycentric.c * vertex2.x + barycentric.d * vertex3.x;
    cartesian.y = barycentric.a * vertex0.y + barycentric.b * vertex1.y + barycentric.c * vertex2.y + barycentric.d * vertex3.y;
    cartesian.z = barycentric.a * vertex0.z + barycentric.b * vertex1.z + barycentric.c * vertex2.z + barycentric.d * vertex3.z;

    return cartesian;
}

void translate_barycentric_to_cartesian(std::vector<vec4> & barycentrics, std::vector<vec3> & cartesians)
{
    for(int i = 0; i < barycentrics.size(); i++)
    {
        cartesians.push_back(translate_single_barycentric_to_cartesian(barycentrics[i]));
    }

}

void write_vec3_to_file(std::vector<vec3> & vectors)
{
    std::ofstream file;
    file.open("points.txt");
    for(int i = 0; i < vectors.size(); i++)
    {
        file << vectors[i].x << " " << vectors[i].y << " " << vectors[i].z << "\n";
    }
}
